import java.applet.Applet;
import java.applet.AudioClip;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;


public class Music {
    AudioClip audioClip;
    public Music(String filename) throws MalformedURLException {
        File file = new File(filename);
        URL url = file.toURL();
        audioClip = Applet.newAudioClip(url);
    }
    public void play(){
        audioClip.loop();
    }

    public void stop(){
        audioClip.stop();
    }
}
