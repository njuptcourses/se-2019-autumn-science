/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sun;

import java.io.InputStream;

/**
 *
 * @author Ridoy
 */
public class audio {

    public static class AudioPlayer {

        public AudioPlayer() {
        }

        public static class player {

            public static void start(AudioStream audio) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            public player() {
            }
        }
    }

    public static class AudioStream {

        public AudioStream() {
        }

        public AudioStream(InputStream in) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }
    
}
